README
This is a simple python script that allows you to calculate C^2, C, and a rounded C.

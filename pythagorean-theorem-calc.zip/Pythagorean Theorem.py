import math
print("This program will output C^2, C and then a rounded version of C.")
raw_x = input("A: ")
raw_y = input("B: ")
unit = input("Units: ")
x = int(raw_x)
y = int(raw_y)
xSQ = x*x
ySQ= y*y
xySQ = xSQ + ySQ
xySQstr = str(xySQ)
print(xySQstr + unit)
xy = (math.sqrt(xySQ))
xySTR = str(xy)
xyRD = round(xy)
xyRDSTR = str(xyRD)
print(xySTR + unit)
print(xyRDSTR + unit)
